<?php
  phpinfo();

  ?>
