$(document).ready(function(){
  $('#tab').click(function(){
    $('.doc').slideToggle();
  })

})
